<body>
 <div class="wrapper">
	<div class="header">
		<h1><?php echo $parameters["page_title"]; ?></h1>
	</div>
<?php
	// Not sure what we should put in the header apart from perhaps
	// navigation :( And right now, there's not a lot of navigation to do...
?>
