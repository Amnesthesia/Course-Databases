
	<div class="container">
		<div class="row">
			<div class="span9">
				<?php include("views/".$view_name.".view.php"); ?>	
			</div>
			<div class="span3">
				<?php include("views/layouts/sidebar.php"); ?>
			</div>
		</div>
	</div>

